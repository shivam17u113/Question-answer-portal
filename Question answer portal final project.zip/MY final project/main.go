package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"time"

	"github.com/go-chi/chi"
	"github.com/go-chi/chi/middleware"
	"github.com/thedevsaddam/renderer"
	mgo "gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
)

var rnd *renderer.Render
var db *mgo.Database

const (
	hostName         string = "localhost:27017"
	dbName           string = "PROJECT"
	collectionName   string = "users"
	r_collectionName string = "REGISTER-LOGIN"
	port             string = ":9000"
)

type (
	todoModel struct {
		ID             bson.ObjectId `bson:"_id,omitempty"`
		Question_Title string        `bson:"question_title"`
		Question_Desc  string        `bson:"question_desc"`
		Answer         []match       `bson:"answer"`
		Done           bool          `bson:"done"`
		Done_See       bool          `bson:"done_see"`
		Temp_Solution  string        `bson:"temp_solution"`
	}

	todo struct {
		ID             string  `json:"id"`
		Question_Title string  `json:"question_title"`
		Question_Desc  string  `json:"question_desc"`
		Answer         []match `json:"answer"`
		Done           bool    `json:"done"`
		Done_See       bool    `json:"done_see"`
		Temp_Solution  string  `bson:"temp_solution"`
	}
	match struct {
		Solution string `json:"solution" bson:"solution"`
		//Upvote   int    `json:"upvote" bson:"upvote"`
		//Downvote int    `json:"downvote" bson:"downvote"`
	}
)

//--------------------------------------------

type (
	r_todoModel struct {
		ID        bson.ObjectId `bson:"_id,omitempty"`
		Name      string        `bson:"name"`
		User_Name string        `bson:"user_name"`
		Password  string        `bson:"password"`
		Email     string        `bson:"email"`
	}

	r_todo struct {
		ID        string `json:"id"`
		Name      string `json:"name"`
		User_Name string `json:"user_name"`
		Password  string `json:"password"`
		Email     string `json:"email"`
	}
)

//==================================

func init() {
	rnd = renderer.New()
	sess, err := mgo.Dial(hostName)
	checkErr(err)
	sess.SetMode(mgo.Monotonic, true)
	db = sess.DB(dbName)
}

func homeHandler(w http.ResponseWriter, r *http.Request) {
	err := rnd.Template(w, http.StatusOK, []string{"static/home.tpl"}, nil)
	checkErr(err)
}

func main() {
	stopChan := make(chan os.Signal)
	signal.Notify(stopChan, os.Interrupt)

	r := chi.NewRouter()
	r.Use(middleware.Logger)
	r.Get("/", homeHandler)

	r.Mount("/todo", todoHandlers())

	r.Mount("/register", r_todoHandlers())

	srv := &http.Server{
		Addr:         port,
		Handler:      r,
		ReadTimeout:  60 * time.Second,
		WriteTimeout: 60 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	go func() {
		log.Println("Listening on port ", port)
		if err := srv.ListenAndServe(); err != nil {
			log.Printf("listen: %s\n", err)
		}
	}()

	<-stopChan
	log.Println("Shutting down server...")
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	srv.Shutdown(ctx)
	defer cancel()
	log.Println("Server gracefully stopped!")
}

func todoHandlers() http.Handler {
	rg := chi.NewRouter()
	rg.Group(func(r chi.Router) {

		r.Post("/", createTodo)
		r.Get("/", fetchTodos)
		//r.Delete("/{id}", deleteTodo)
		r.Put("/{id}", updateTodo)

	})
	return rg
}

func r_todoHandlers() http.Handler {
	rg := chi.NewRouter()
	rg.Group(func(r chi.Router) {

		r.Post("/", r_createTodo)
		r.Get("/", r_fetchTodos)
		//r.Delete("/{id}", deleteTodo)
		//r.Put("/{id}", updateTodo)

	})
	return rg
}

/*func deleteTodo(w http.ResponseWriter, r *http.Request) {
	id := strings.TrimSpace(chi.URLParam(r, "id"))

	if !bson.IsObjectIdHex(id) {
		rnd.JSON(w, http.StatusBadRequest, renderer.M{
			"message": "The id is invalid",
		})
		return
	}

	if err := db.C(collectionName).RemoveId(bson.ObjectIdHex(id)); err != nil {
		rnd.JSON(w, http.StatusProcessing, renderer.M{
			"message": "Failed to delete todo",
			"error":   err,
		})
		return
	}

	rnd.JSON(w, http.StatusOK, renderer.M{
		"message": "Todo deleted successfully",
	})
}*/

func createTodo(w http.ResponseWriter, r *http.Request) {
	var t todo

	if err := json.NewDecoder(r.Body).Decode(&t); err != nil {
		rnd.JSON(w, http.StatusProcessing, err)
		return
	}

	// simple validation
	if t.Question_Title == "" {
		rnd.JSON(w, http.StatusBadRequest, renderer.M{
			"message": "The title field is requried",
		})
		return
	}

	// if input is okay, create a todo
	tm := todoModel{
		ID:             bson.NewObjectId(),
		Question_Desc:  t.Question_Desc,
		Question_Title: t.Question_Title,
		Answer:         t.Answer,
		Done:           false,
		Done_See:       false,
		Temp_Solution:  t.Temp_Solution,
	}
	if err := db.C(collectionName).Insert(&tm); err != nil {
		rnd.JSON(w, http.StatusProcessing, renderer.M{
			"message": "Failed to save todo",
			"error":   err,
		})
		return
	}

	rnd.JSON(w, http.StatusCreated, renderer.M{
		"message": "Todo created successfully",
		"todo_id": tm.ID.Hex(),
	})
}

//-------------------------------------------------------

func r_createTodo(w http.ResponseWriter, r *http.Request) {
	var t r_todo

	if err := json.NewDecoder(r.Body).Decode(&t); err != nil {
		rnd.JSON(w, http.StatusProcessing, err)
		return
	}

	// simple validation
	if t.Name == "" {
		rnd.JSON(w, http.StatusBadRequest, renderer.M{
			"message": "The title field is requried",
		})
		return
	}

	// if input is okay, create a todo
	tm := r_todoModel{
		ID:        bson.NewObjectId(),
		Name:      t.Name,
		User_Name: t.User_Name,
		Password:  t.Password,
		Email:     t.Email,
	}
	if err := db.C(r_collectionName).Insert(&tm); err != nil {
		rnd.JSON(w, http.StatusProcessing, renderer.M{
			"message": "Failed to save todo",
			"error":   err,
		})
		return
	}

	rnd.JSON(w, http.StatusCreated, renderer.M{
		"message": "Todo created successfully",
		"todo_id": tm.ID.Hex(),
	})
}

//==========================================================

func updateTodo(w http.ResponseWriter, r *http.Request) {
	fmt.Println("In update todo")
	fmt.Println("response", r)
	id := strings.TrimSpace(chi.URLParam(r, "id"))

	if !bson.IsObjectIdHex(id) {
		rnd.JSON(w, http.StatusBadRequest, renderer.M{
			"message": "The id is invalid",
		})
		return
	}

	var t todo

	if err := json.NewDecoder(r.Body).Decode(&t); err != nil {
		rnd.JSON(w, http.StatusProcessing, err)
		fmt.Println("in decoder_________________________________________________________")
		fmt.Print("the error is+++++++++", err)
		return
	}
	fmt.Println("Decoded data==", t.Answer)
	// simple validation
	if t.Question_Desc == "" {
		rnd.JSON(w, http.StatusBadRequest, renderer.M{
			"message": "The title field is requried",
		})
		return
	}
	fmt.Println("TRYITFYGUHLKJGIHIYUVHLBJ", t.Answer)
	fmt.Println(t.Question_Title)
	// if input is okay, update a todo
	if err := db.C(collectionName).
		Update(
			bson.M{"_id": bson.ObjectIdHex(id)},
			bson.M{"question_title": t.Question_Title, "question_desc": t.Question_Desc, "done": t.Done, "done_see": t.Done_See, "temp_solution": t.Temp_Solution, "answer": t.Answer},
		); err != nil {
		rnd.JSON(w, http.StatusProcessing, renderer.M{
			"message": "Failed to update todo",
			"error":   err,
		})

		return
	}

	rnd.JSON(w, http.StatusOK, renderer.M{
		"message": "Todo updated successfully",
	})
}

func fetchTodos(w http.ResponseWriter, r *http.Request) {
	todos := []todoModel{}

	if err := db.C(collectionName).
		Find(bson.M{}).
		All(&todos); err != nil {
		rnd.JSON(w, http.StatusProcessing, renderer.M{
			"message": "Failed to fetch todo",
			"error":   err,
		})
		return
	}

	todoList := []todo{}
	for _, t := range todos {
		todoList = append(todoList, todo{
			ID:             t.ID.Hex(),
			Question_Desc:  t.Question_Desc,
			Question_Title: t.Question_Title,
			Answer:         t.Answer,
			Done:           t.Done,
			Done_See:       t.Done_See,
			Temp_Solution:  t.Temp_Solution,
		})
	}

	rnd.JSON(w, http.StatusOK, renderer.M{
		"data": todoList,
	})
}

//---------------------------------------------------------

func r_fetchTodos(w http.ResponseWriter, r *http.Request) {
	todos := []r_todoModel{}

	if err := db.C(r_collectionName).
		Find(bson.M{}).
		All(&todos); err != nil {
		rnd.JSON(w, http.StatusProcessing, renderer.M{
			"message": "Failed to fetch todo",
			"error":   err,
		})
		return
	}

	todoList := []r_todo{}
	for _, t := range todos {
		todoList = append(todoList, r_todo{
			ID:        t.ID.Hex(),
			Name:      t.Name,
			User_Name: t.User_Name,
			Password:  t.Password,
			Email:     t.Email,
		})
	}

	rnd.JSON(w, http.StatusOK, renderer.M{
		"data": todoList,
	})
}

//=========================================

func checkErr(err error) {
	if err != nil {
		log.Fatal(err) //respond with error page or message
	}
}

//if (!(this.name="") && !(this.user_name="") && !(this.email="") && !(this.password="" ) && !(this.conf_password=""))
//{
//if (this.password === this.conf_password)
//{

//<div v-for="(todo, todoIndex) in todos" class="checkbox">

//<input type="checkbox"  value="second_checkbox">  <label> @{ todo.title }</label>  <input type="submit" v-on:click="deleteTodo(todo, todoIndex)">

//</div>
